//
//  AppDelegate.swift
//  Sample
//
//  Created by 1amageek on 2017/03/15.
//  Copyright © 2017年 Stamp inc. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?
    var session: URLSession?
    
}

