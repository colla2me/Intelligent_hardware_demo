//
//  ExtendaBLE.h
//  ExtendaBLE
//
//  Created by Anton on 3/30/17.
//  Copyright © 2017 Anton Doudarev. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for ExtendaBLE.
FOUNDATION_EXPORT double ExtendaBLEVersionNumber;

//! Project version string for ExtendaBLE.
FOUNDATION_EXPORT const unsigned char ExtendaBLEVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ExtendaBLE/PublicHeader.h>


